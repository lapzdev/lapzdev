console.log("Nuevo JavaScript");
